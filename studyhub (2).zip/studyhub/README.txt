STUDYHUB (formerly StudySnap)
Quizzes (standard / SAT / AP, photo or description, auto-retake on weak spots), study guides & cheat sheets,
GPA + per-class grade calculator, brutal writing feedback, assignment answers from a photo, and SugAI
(chat for any question + image generation). Everything is saved per device, in the browser.

SETUP (no terminal needed on Windows)
1. Install Node.js from https://nodejs.org (one time).
2. Copy  config.example.env  to a new file named  config.env  and fill in your AI details
   (see the file for a hosted AI like Nebius, or for a free AI on your own PC with Ollama).
3. Double-click  start.bat . Your browser opens the site. Leave the black window open while you use it.
   (Mac/Linux: run  node server.mjs  in this folder, then open http://127.0.0.1:3000)

TEST ON YOUR PHONE: run with HOST=0.0.0.0 (PowerShell: $env:HOST="0.0.0.0") and open http://YOUR-PC-IP:3000
on the same Wi-Fi. Camera needs HTTPS or localhost, so for the in-browser camera on a phone, deploy it (below).
The "Take photo" button uses the phone's own camera app and works either way.

LETTING OTHER PEOPLE USE IT
Deploy this folder to any Node host (Render, Railway, Fly.io...) and set the key as an environment variable
there. Every visitor automatically gets their own private data (it lives in their own browser, not on your server).
Note: all visitors' AI use is billed to YOUR key. The app itself has NO limits, but your AI provider may rate-limit;
the server automatically retries those and shows a friendly message if it's still busy.

ABOUT "Too many quizzes in a short time"
That text is not anywhere in this project. It came from whatever was hosting/serving the old version (or an AI provider).
This version never blocks you by itself.

NOTES
- Chats, quizzes, guides and grades are stored in the browser (localStorage) per device. Clearing browser data
  or switching devices starts fresh. Use "Erase all my data" at the bottom to wipe it yourself.
- Image generation uses the free Pollinations service through your server (no key).
- SugAI looks up live web info quietly on the server (DuckDuckGo) and answers in its own words.
- AI can make mistakes. Check important answers.

FASTER + SMARTER (optional)
- SugAI answers now appear word-by-word as they are written, and big quizzes are made in two parallel halves.
- You can use different models per job. Set these (in config.env or Render's Environment page):
    AI_MODEL_FAST    small/quick model for SugAI chat
    AI_MODEL_SMART   bigger model for quizzes, essay grading, guides, homework answers
    AI_MODEL_VISION  model that can read photos (used automatically when a photo is attached)
  Anything you leave out falls back to AI_MODEL.
- Bigger models are smarter but slower; smaller ones are faster but make more mistakes.

IMAGES
- Tap the picture button in SugAI, choose a style (photo, illustration, anime, painting, 3D, logo) and a shape
  (square, wide, tall), then describe what you want. The AI first rewrites your idea into a detailed prompt
  (you can see it under "Prompt used"), then the image is made with FLUX. "Another version" remakes it.
- Free images without an account are rate-limited (roughly one every 15 seconds), so requests are queued one at a time.
  For faster, more reliable images, make a free account at https://enter.pollinations.ai and set POLLINATIONS_KEY.

VIDEO (SugAI, tap the film-clip button)
- Make a short clip (4, 6 or 8 seconds) from a description, or attach a drawing, pet, object or scene to animate it.
- Needs POLLINATIONS_KEY with credits (https://enter.pollinations.ai). Without it, video may be refused.
- Animating an attached image only works on the deployed website (the video service must be able to reach it).
- Safety: videos of real people are blocked. Every request is checked, and every attached image is checked for
  photos of people. If the check can't run, the request is refused.
- Videos are kept on the server for about 30 minutes, so use "Save video".

RELIABILITY + SPEED
- Quizzes, grading and essay feedback automatically retry once if the AI returns a broken answer.
- Study guides, cheat sheets and homework answers now appear as they are written.
- If a model name in AI_MODEL_SMART / FAST / VISION is wrong or unavailable, the server falls back to AI_MODEL.
- The page is sent compressed (about 3x smaller) so it loads faster.
- Keep-awake: the free Render plan sleeps after 15 minutes. A free uptime monitor (for example UptimeRobot) that opens
  https://YOUR-SITE.onrender.com/health every 5 minutes keeps it awake so nobody waits 30-50 seconds.
  One always-on service uses about 744 hours a month, which fits Render's 750 free hours if it is your only service.
