@echo off
cd /d "%~dp0"
where node >nul 2>nul || (echo Please install Node.js from https://nodejs.org first, then run this again. & pause & exit /b)
start "" http://127.0.0.1:3000
node server.mjs
pause
